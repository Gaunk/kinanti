<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation', 'url');
        $this->load->helper('text');
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'My Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
    }


    public function edit()
    {
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('templates/footer');
        } else {
            $name = $this->input->post('name');
            $email = $this->input->post('email');

            // cek jika ada gambar yang akan diupload
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']      = '2048';
                $config['upload_path'] = './assets/img/profile/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['user']['image'];
                    if ($old_image != 'default.jpg') {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('image', $new_image);
                } else {
                    echo $this->upload->dispay_errors();
                }
            }

            $this->db->set('name', $name);
            $this->db->where('email', $email);
            $this->db->update('user');

            $this->session->set_flashdata('message', '<div class="text-center alert alert-success" role="alert">Your profile has been updated!</div>');
            redirect('user');
        }
    }


    public function changePassword()
    {
        $data['title'] = 'Change Password';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('current_password', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('new_password1', 'New Password', 'required|trim|min_length[3]|matches[new_password2]');
        $this->form_validation->set_rules('new_password2', 'Confirm New Password', 'required|trim|min_length[3]|matches[new_password1]');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/changepassword', $data);
            $this->load->view('templates/footer');
        } else {
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password1');
            if (!password_verify($current_password, $data['user']['password'])) {
                $this->session->set_flashdata('message', '<div class="text-center alert alert-danger" role="alert">Wrong current password!</div>');
                redirect('user/changepassword');
            } else {
                if ($current_password == $new_password) {
                    $this->session->set_flashdata('message', '<div class="text-center alert alert-danger" role="alert">New password cannot be the same as current password!</div>');
                    redirect('user/changepassword');
                } else {
                    // password sudah ok
                    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                    $this->db->set('password', $password_hash);
                    $this->db->where('email', $this->session->userdata('email'));
                    $this->db->update('user');

                    $this->session->set_flashdata('message', '<div class="text-center alert alert-success" role="alert">Password changed!</div>');
                    redirect('user/changepassword');
                }
            }
        }
    }

    // ////////////////////////////////////////////////////////////////////////////
    // BLOCK PRODUK COOY
// ////////////////////////////////////////////////////////////////////////////
public function produk()
    {
        $this->load->model('Produk_model', 'produk');
        $data['title'] = 'Dashboard | Produk';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['produk'] = $this->produk->getAllProduk();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/produk', $data);
        
    }

    public function tambahproduk()
    {
        $this->load->model('Produk_model', 'produk');
        $data['title'] = 'Dashboard | Produk';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['produk'] = $this->produk->getAllProduk();
        $this->form_validation->set_rules('name','Nama Produk', 'required');
          $this->form_validation->set_rules('deskripsi','Deskripsi', 'required');
          $this->form_validation->set_rules('harga','Harga', 'required');
          $this->form_validation->set_rules('status','Status', 'required');
          $this->form_validation->set_rules('stock','Stock', 'required');
          $this->form_validation->set_rules('kategori','Kategori', 'required');
         

          if($this->form_validation->run() == false) {
              $this->load->view('templates/header', $data);
              $this->load->view('templates/sidebar', $data);
              $this->load->view('templates/topbar', $data);
              $this->load->view('admin/tambahproduk', $data);
              $this->load->view('templates/footer');

          } else {
            $gambar = $_FILES['gambar']['name'];

            if ($gambar = '') {
            } else {
                $config['allowed_types'] = 'jpg|png|jpeg';
                $config['max_size']     = '1048';
                $config['upload_path'] = './assets/img/produk/';
                $config['encrypt_name'] = TRUE;

                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('gambar')) {
                    $this->session->set_flashdata('pesan', '
                        <div class="alert alert-danger text-center" role="alert">
                         Produk gagal ditambahkan, cek kembali ukuran gambar dan tipe file gambar!
                         </div>
                        ');
                    redirect('user/tambahproduk');
                } else {
                    $gambar = $this->upload->data('file_name', true);

                    $data = [
                        "name" => $this->input->post('name', true),
                        "deskripsi" => $this->input->post('deskripsi', true),
                        "harga" => $this->input->post('harga', true),
                        "status" => $this->input->post('status', true),
                        "stock" => $this->input->post('stock', true),
                        "kategori" => $this->input->post('kategori', true),
                        "tanggal" => $this->input->post('tanggal', true),                
                        "user" => $this->input->post('user', true),
                        "gambar" => $gambar
                    ];
                }
                $this->produk->tambahProduk($data, 'produk');
                $this->session->set_flashdata('pesan', '
                <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
                  <strong>Produk!</strong> Sukses ditambahkan!!.
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                ');
                redirect('user/produk');

          }
      }
        
    }

}
