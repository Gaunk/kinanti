<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	    {
	        parent::__construct();
	        $this->load->library('form_validation', 'url');
	        $this->load->helper('text');
	    }
	public function index()
	{
		$this->load->model('Berita_model', 'berita');
		$this->load->model('Produk_model', 'produk');
		$data['judul'] = 'PT Kinanti Sejahtera Lestari';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['berita'] = $this->berita->getAllBerita();
        $data['produk'] = $this->produk->getAllProduk();
        
		$this->load->view('home/head', $data);
		$this->load->view('home/header', $data);
		$this->load->view('home', $data);
		$this->load->view('home/footer', $data);
	}
}
